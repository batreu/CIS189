def print_dictionary(sharks_dict):
    for key, value in sharks_dict.items():
        print(key, value)