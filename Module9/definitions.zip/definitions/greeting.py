def friendly_greeting():
    print("Hello there! *in Obi-Wan voice*")


def print_author(code_author):
    print(code_author, 'is the author.')