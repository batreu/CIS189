def print_set(mountain_ranges):
    for x in mountain_ranges:
        print(x)